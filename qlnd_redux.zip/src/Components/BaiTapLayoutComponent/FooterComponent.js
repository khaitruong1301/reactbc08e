import React, { Component } from 'react'

export default class FooterComponent extends Component {
    render() {
        return (
            <div className="bg-danger text-white navigation display-4 d-flex justify-content-center align-items-center">
            <div>Footer component</div> 
        </div>
        )
    }
}
