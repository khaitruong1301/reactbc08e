// import FunctionComponent from "./Components/FunctionComponent";
// import ClassComponent from "./Components/ClassComponent";
// import HomeComponent from "./Components/BaiTapLayoutComponent/HomeComponent";
// import Databinding from "./Databinding/Databinding"
// import BaiTapThucHanhLayout from "./Components/BaiTapThucHanhLayout/BaiTapThucHanhLayout";
// import Demo from "./Databinding/Demo";
// import HandleEvent from "./HandleEvent/HandleEvent";
// import StyleComponent from "./StyleComponent/StyleComponent";
// import StateDemo from "./StateDemo/StateDemo"
// import HomeLayout from "./Props/DemoProps/HomeLayout";
// import RenderWithMap from "./RenderWithMap/RenderWithMap";
// import ShoesShop from "./Props/ShoesShop/ShoesShop";
// import BaiTapXemChiTiet from "./Props/BaiTapXemChiTiet/BaiTapXemChiTiet";
// import ExerciseCarStore from "./Props/ExerciseCarStore/ExerciseCarStore";
// import ExerciseCarStore from "./Props/ExerciseCarStore/ExerciseCarStore";

// import BaiTapGioHang from "./DemoRedux/BaiTapGioHang/BaiTapGioHang";

// import ExerciseCart from "./Props/ExerciseCart/ExerciseCart";
// import BaiTapGameXucXac from "./DemoRedux/BaiTapGameXucXac/BaiTapGameXucXac";
import BaiTapQuanLyNguoiDung from "./DemoRedux/BaiTapQuanLyNguoiDung/BaiTapQuanLyNguoiDung";
function App() {
  return (
    <div className="App">
          {/* <HomeComponent /> */}
          {/* <Databinding /> */}
          {/* <BaiTapThucHanhLayout /> */}
          {/* <Demo />  */}
        
          {/* <HandleEvent></HandleEvent> */}

          {/* <StyleComponent /> */}
          {/* <p className="fontBold">ahihi</p> */}
          {/* <StateDemo /> */}
          {/* <HomeLayout /> */}
          {/* <RenderWithMap /> */}
          {/* <ShoesShop /> */}
          {/* <BaiTapXemChiTiet /> */}
          {/* <ExerciseCarStore /> */}
          {/* <ExerciseCart /> */}
          {/* <BaiTapGioHang /> */}
          {/* <BaiTapGameXucXac /> */}
          <BaiTapQuanLyNguoiDung />
    </div>
  );
}

export default App;


