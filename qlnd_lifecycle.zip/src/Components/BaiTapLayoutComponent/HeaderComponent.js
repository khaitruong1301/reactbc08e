import React, { Component } from 'react'

export default class HeaderComponent extends Component {




    render() {
        return (
            <div className="header">
                Header component
            </div>
        )
    }
}
