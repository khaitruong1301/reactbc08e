import React, { Component } from 'react'

export default class ContentComponent extends Component {
    render() {
        return (
            <div className="bg-primary text-white navigation display-4 d-flex justify-content-center align-items-center">
            <div>
                Content    
            </div> 
        </div>
        )
    }
}
